﻿using System.Windows.Controls;

namespace SpriteFactory.Sprites
{
    /// <summary>
    /// Interaction logic for SpriteEditorView.xaml
    /// </summary>
    public partial class SpriteEditorView : UserControl
    {
        public SpriteEditorView()
        {
            InitializeComponent();
        }
    }
}
