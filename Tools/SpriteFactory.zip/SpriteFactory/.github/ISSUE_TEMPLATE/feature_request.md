---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**What's the story?**
Always start with the purpose. What problem are you trying to solve? How did you get here?

**Describe the solution you'd like**
Describe what you want to happen. 

Add any other context or screenshots as needed.
